<button type="button">
    Notifications ({{ $unreadNotificationsCount }} unread)
</button>