<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\NewSystemRes\vendor\filament\forms\src\/../resources/views/components/group.blade.php ENDPATH**/ ?>