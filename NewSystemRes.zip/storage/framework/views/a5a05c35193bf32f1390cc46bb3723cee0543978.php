<svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
</svg><?php /**PATH C:\xampp\htdocs\NewSystemRes\storage\framework\views/9101f878dca114f2017df682ce04ffd0df6d62ee.blade.php ENDPATH**/ ?>