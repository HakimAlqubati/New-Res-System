<p <?php echo e($attributes->class([
    'filament-notifications-date text-xs text-gray-500',
    'dark:text-gray-300' => config('notifications.dark_mode'),
])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\xampp\htdocs\NewSystemRes\vendor\filament\notifications\src\/../resources/views/components/date.blade.php ENDPATH**/ ?>